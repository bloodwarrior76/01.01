#include <iostream>
int main(){
std::cout<<"help"<<std::endl;
}
